package com.teamsankya.mybank.application;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/api")
public class RestApplication extends Application{

}// End of class: RestApplication
