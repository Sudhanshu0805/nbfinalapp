package com.teamsankya.mybank.rootresources;

import java.util.Calendar;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.teamsankya.mybank.dto.CardDetails;
import com.teamsankya.mybank.dto.TransactionDetails;
import com.teamsankya.mybank.utility.TransactionStatus;

@Path("/myBank/payment")
public class MyBank {
	
	@Path("/cardPay")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public TransactionDetails cardPayment(CardDetails cardDetails) {
		
		TransactionDetails transactionDetails = null;
		
		if (cardDetails == null
				|| (cardDetails.getCardNumber() + "").length() != 16
				|| (cardDetails.getCvv() + "").length() != 3
				|| cardDetails.getExpiryMonth() < 1
				|| cardDetails.getExpiryMonth() > 12
				|| cardDetails.getExpiryYear() < Calendar.getInstance().getWeekYear()
				|| ((cardDetails.getExpiryYear() == Calendar.getInstance().getWeekYear())
						&& cardDetails.getExpiryMonth() < (Calendar.getInstance().get(Calendar.MONTH) + 1)) ) {
			
			transactionDetails = new TransactionDetails(TransactionStatus.STATUS_FAILED);
			transactionDetails.setMessage("Invalid Card Details");
			
			return transactionDetails;
			
		}// end of if
		
		transactionDetails = new TransactionDetails(TransactionStatus.STATUS_SUCCESS);
		transactionDetails.setMessage("Payment Received.");
		
		return transactionDetails;
		
	}// End of cardPayment()
	
}// End of class: MyBank
