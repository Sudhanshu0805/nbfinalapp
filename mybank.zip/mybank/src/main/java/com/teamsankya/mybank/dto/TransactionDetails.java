package com.teamsankya.mybank.dto;

import java.net.InetAddress;
import java.util.Calendar;
import java.util.Random;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.net.ntp.NTPUDPClient;
import org.apache.commons.net.ntp.NtpV3Packet;
import org.apache.commons.net.ntp.TimeInfo;

import com.teamsankya.mybank.utility.TransactionStatus;

@XmlRootElement(name = "TransactionStatus-Details")
@XmlAccessorType(XmlAccessType.FIELD)
public class TransactionDetails {

	@XmlElement
	int statusCode;
	
	@XmlElement
	private String status;
	
	@XmlElement
	private long transactionID;
	
	@XmlElement
	private String transactionDate;
	
	@XmlElement
	private String transactionTime;
	
	@XmlElement
	private String message;

	// Constructors
	public TransactionDetails() {
		statusCode = TransactionStatus.STATUS_CODE_FOR_FAILURE;
		status = TransactionStatus.STATUS_FAILED;
		transactionDate = "-";
		transactionTime = "-";
		message = "Invalid Data";
		
	}// end of constructor()

	public TransactionDetails(String status) {
		Random random = new Random();
		transactionID = Math.abs(random.nextLong());
		setTxDateAndTime();

		if (status.equalsIgnoreCase("Successful")
				|| status.equalsIgnoreCase("Success")
				|| status.equalsIgnoreCase(TransactionStatus.STATUS_SUCCESS)) {
			
			statusCode = TransactionStatus.STATUS_CODE_FOR_SUCCESS;
			this.status = TransactionStatus.STATUS_SUCCESS;
			message = "Transaction Successful.";
			
		} else {
			this.status = TransactionStatus.STATUS_FAILED;
			statusCode = TransactionStatus.STATUS_CODE_FOR_FAILURE;
			message = "Invalid Card Details!!!";
			
		}// end of if-else
		
	}// end of Constructor(with status)

	// Getters and Setters
	
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public long getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(long transactionID) {
		this.transactionID = transactionID;
	}

	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionTime() {
		return transactionTime;
	}
	public void setTransactionTime(String transactionTime) {
		this.transactionTime = transactionTime;
	}

	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	private void setTxDateAndTime() {
		String timeServer = "time.nist.gov";
		Calendar calendar = Calendar.getInstance();
		try {
			InetAddress inetAddress = InetAddress.getByName(timeServer);
			NTPUDPClient ntpudpClient = new NTPUDPClient();
			TimeInfo timeInfo = ntpudpClient.getTime(inetAddress);
			NtpV3Packet message = timeInfo.getMessage();
			long serverTime = message.getTransmitTimeStamp().getTime();
			
			calendar.setTimeInMillis(serverTime);


		} catch (Exception e) {
			System.out.println("Error Fetching Time From Internet.");
			System.out.println("Using System Date And Time For TransactionStatus.");
			
		}// end of try-catch
		
		transactionDate = "" + calendar.get(Calendar.DAY_OF_MONTH) + "-" + (calendar.get(Calendar.MONTH) + 1) + "-" + calendar.get(Calendar.YEAR);
		transactionTime = "" + calendar.get(Calendar.HOUR_OF_DAY) + ":" + calendar.get(Calendar.MINUTE) + ":" + calendar.get(Calendar.SECOND);
		
	}// end of setTxDateAndTime()

}// End of class: TransactionDetails
