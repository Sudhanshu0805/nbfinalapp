package com.teamsankya.mybank.utility;

public interface TransactionStatus {
	
	String STATUS_FAILED = "Failed";
	String STATUS_SUCCESS = "Successful";
	
	int STATUS_CODE_FOR_FAILURE = 0;
	int STATUS_CODE_FOR_SUCCESS = 1;

}// End of interface: TransactionStatus
