package com.teamsankya.shoppingcart.dao;

import java.util.List;

import com.teamsankya.shoppingcart.dto.CardDetails;
import com.teamsankya.shoppingcart.dto.ProductBean;
import com.teamsankya.shoppingcart.dto.UserBean;

public interface CartDAO {
	UserBean login(String userId, String password);
	boolean register(UserBean bean);
	List<ProductBean> getProducts();
	List<ProductBean> getProducts(String name);
	ProductBean getProduct(String id);
	boolean addProduct(ProductBean productBean);
	boolean payNow(CardDetails cardDetails, String pid, UserBean userBean);
}
