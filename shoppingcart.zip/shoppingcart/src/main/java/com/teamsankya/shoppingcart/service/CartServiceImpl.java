package com.teamsankya.shoppingcart.service;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;

import com.teamsankya.shoppingcart.dao.CartDAO;
import com.teamsankya.shoppingcart.dto.CardDetails;
import com.teamsankya.shoppingcart.dto.ProductBean;
import com.teamsankya.shoppingcart.dto.TransactionDetails;
import com.teamsankya.shoppingcart.dto.UserBean;

public class CartServiceImpl implements CartService {

	@Autowired
	CartDAO cartDAO;

	@Override
	public UserBean login(String userId, String password) {

		return cartDAO.login(userId, password);
	}// end of login()

	@Override
	public boolean register(UserBean userBean, String retypePassword) {

		if (userBean == null || retypePassword == null) {
			return false;
		}

		// Removing White Spaces present at the start and end of the field values.
		userBean.setUserId(userBean.getUserId().trim());
		userBean.setEmail(userBean.getEmail().trim());
		userBean.setPassword(userBean.getPassword().trim());
		userBean.setAddress(userBean.getAddress().trim());
		userBean.setCity(userBean.getCity().trim());
		userBean.setState(userBean.getState().trim());

		retypePassword = retypePassword.trim();

		// Registering User only if Password and Retype Password are same.
		if (!userBean.getPassword().equals(retypePassword) || userBean.getPassword().length() < 4
				|| userBean.getUserId().length() < 3 || !userBean.getUserId().matches("[a-zA-Z][\\w.#_]+[\\w]")
				|| !(userBean.getEmail().contains("@") && userBean.getEmail().contains("."))
				|| userBean.getEmail().indexOf("@") != userBean.getEmail().lastIndexOf("@")
				|| (userBean.getEmail().lastIndexOf(".") - userBean.getEmail().indexOf("@") < 2)
				|| userBean.getEmail().length() - userBean.getEmail().lastIndexOf(".") == 1
				|| (userBean.getPincode() + "").length() != 6 || (userBean.getPhoneNumber() + "").length() != 10) {

			return false;
		}

		return cartDAO.register(userBean);

	}// end of register()

	@Override
	public List<ProductBean> getProducts() {

		return cartDAO.getProducts();
	}// end of getProducts()

	@Override
	public List<ProductBean> getProducts(String name) {

		return cartDAO.getProducts(name);
	}// end of getProducts(name)

	@Override
	public ProductBean getProduct(String id) {

		return cartDAO.getProduct(id);
	}// end of getProducts(id)

	@Override
	public TransactionDetails payNow(CardDetails cardDetails, String pid, UserBean userBean) {

		TransactionDetails transactionDetails = null;
		
		if (userBean == null
				|| userBean.getUserId() == null
				|| userBean.getUserId().trim().isEmpty()
				|| userBean.getType() == null
				|| userBean.getType().trim().isEmpty()
				|| !(userBean.getType().equalsIgnoreCase("C")
						|| userBean.getType().equalsIgnoreCase("U")
						|| userBean.getType().equalsIgnoreCase("B"))
				
				|| pid == null || pid.trim().isEmpty()
				
				/*|| cardDetails == null
				|| (cardDetails.getCardNumber() + "").length() != 16
				|| (cardDetails.getCvv() + "").length() != 3
				|| cardDetails.getExpiryMonth() < 1
				|| cardDetails.getExpiryMonth() > 12
				|| cardDetails.getExpiryYear() < Calendar.getInstance().getWeekYear()
				|| ((cardDetails.getExpiryYear() == Calendar.getInstance().getWeekYear())
						&& cardDetails.getExpiryMonth() < (Calendar.getInstance().get(Calendar.MONTH) + 1)) */ ) {

			System.out.println("\n\nCan't Place Order!!!\nUser Detail and/or Product Details are not currect!\n\n");
			return transactionDetails;
		
		} else if(cardDetails == null) {
			
			System.out.println("\n\nPayment Can't Be Processed!!!\nCard details not given!\n\n");
			return transactionDetails;
			
		}// end of if-else
		
		String bankURL = "http://localhost:8080/mybank/api/myBank/payment/cardPay";
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(bankURL);
		Response response = target.request(MediaType.APPLICATION_JSON).post(Entity.json(cardDetails));
		
		transactionDetails = response.readEntity(TransactionDetails.class);
		
		if (transactionDetails.getStatusCode() == 1) {
			cartDAO.payNow(cardDetails, pid, userBean);
		}
		
		return transactionDetails;
		
		
		
		
		
/*		System.out.println("userBean == null : " + userBean == null);
		System.out.println("userBean.getUserId() == null : " + userBean.getUserId() == null);
		
		System.out.println("userBean.getUserId().trim().isEmpty() : " + userBean.getUserId().trim().isEmpty());
		System.out.println("userBean.getType() == null : " + userBean.getType() == null);
		System.out.println("userBean.getType().trim().isEmpty() : " + userBean.getType().trim().isEmpty());
		System.out.print("!(userBean.getType().equalsIgnoreCase(\"C\") || userBean.getType().equalsIgnoreCase(\"U\") || userBean.getType().equalsIgnoreCase(\"B\")) : ");
		System.out.println(!(userBean.getType().equalsIgnoreCase("C")
				|| userBean.getType().equalsIgnoreCase("U")
				|| userBean.getType().equalsIgnoreCase("B")));
		System.out.println();
		
		System.out.println("pid == null : " + pid == null );
		System.out.println("pid.trim().isEmpty() : " + pid.trim().isEmpty());
		System.out.println();
		
		System.out.println("cardDetails == null : " + cardDetails == null);
		System.out.println("(cardDetails.getCardNumber() + \"\").length() != 16 : " + ((cardDetails.getCardNumber() + "").length() != 16));
		System.out.println("(cardDetails.getCvv() + \"\").length() != 3 : " + ((cardDetails.getCvv() + "").length() != 3));
		System.out.println("cardDetails.getExpiryMonth() < 1 : " + (cardDetails.getExpiryMonth() < 1));
		System.out.println("cardDetails.getExpiryMonth() > 12 : " + (cardDetails.getExpiryMonth() > 12));
		System.out.print("cardDetails.getExpiryYear() < Calendar.getInstance().getWeekYear() : ");System.out.println(cardDetails.getExpiryYear() < Calendar.getInstance().getWeekYear());
		System.out.print("((cardDetails.getExpiryYear() == Calendar.getInstance().getWeekYear())\r\n" + 
				"						&& cardDetails.getExpiryMonth() < (Calendar.getInstance().get(Calendar.MONTH) + 1)) : ");
		System.out.println(((cardDetails.getExpiryYear() == Calendar.getInstance().getWeekYear())
					&& cardDetails.getExpiryMonth() < (Calendar.getInstance().get(Calendar.MONTH) + 1)));
		
		System.out.println();
		System.out.println("cardDetails.getExpiryYear() : " + cardDetails.getExpiryYear());
		System.out.println("Calendar.getInstance().getWeekYear() : " + Calendar.getInstance().getWeekYear());
		System.out.println("Calendar.getInstance().get(Calendar.MONTH) : " + Calendar.getInstance().get(Calendar.MONTH));
		System.out.println("(Calendar.getInstance().get(Calendar.MONTH) + 1) : " + (Calendar.getInstance().get(Calendar.MONTH) + 1));
		System.out.println("cardDetails.getExpiryYear() < Calendar.getInstance().getWeekYear() : " + (cardDetails.getExpiryYear() < Calendar.getInstance().getWeekYear()));
		System.out.println("cardDetails.getExpiryMonth() < (Calendar.getInstance().get(Calendar.MONTH) + 1) : " + (cardDetails.getExpiryMonth() < (Calendar.getInstance().get(Calendar.MONTH) + 1)));
*/			
		
	}// end of payNow()

	@Override
	public boolean addProduct(ProductBean productBean, UserBean userBean) {
		if (productBean == null || userBean == null) {
			return false;
		}

		// Removing white spaces from start and end position of fields value
		productBean.setId(productBean.getId().trim());
		productBean.setName(productBean.getName().trim());

		if (userBean.getUserId() != null && !userBean.getUserId().matches("-[\\w]+")
				&& userBean.getType().equalsIgnoreCase("S") && productBean != null && productBean.getName() != null
				&& !productBean.getName().isEmpty() && productBean.getQuantity() >= 0
				&& productBean.getQuantity() < 10001 && productBean.getPrice() > 0 && productBean.getId() != null
				&& !productBean.getId().matches("-[\\w]+")) {

			productBean.setUserBean(userBean);
			return cartDAO.addProduct(productBean);
			
		}// end of if

		return false;

	}// end of addProduct()

}// End of CartServiceImpl
