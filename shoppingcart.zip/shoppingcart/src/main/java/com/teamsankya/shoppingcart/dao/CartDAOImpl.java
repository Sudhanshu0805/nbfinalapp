package com.teamsankya.shoppingcart.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;

import com.teamsankya.shoppingcart.dto.CardDetails;
import com.teamsankya.shoppingcart.dto.OrderBean;
import com.teamsankya.shoppingcart.dto.ProductBean;
import com.teamsankya.shoppingcart.dto.UserBean;

public class CartDAOImpl implements CartDAO {

	@Autowired
	SessionFactory sessionFactory;

	/*
	 * In constructor, open Session only once using SessionFactory for all the
	 * operations. Later use the same session using getCurrentSession() of
	 * SessionFactory instead of openSession().
	 */
	public void init() {
		//sessionFactory.openSession();

		/*
		 * UserBean userBean = new UserBean(); userBean.setUserId("1111zzzz");
		 * userBean.setEmail(""); userBean.setType("S"); userBean.setPassword("QWERTY");
		 * userBean.setAddress("BTM, Stage-I"); userBean.setCity("Bangalore");
		 * userBean.setState("Karnataka"); userBean.setPincode(560021);
		 * userBean.setPhoneNumber(8770134456L);
		 * 
		 * CardDetails cardDetails = new CardDetails();
		 * cardDetails.setCardNumber(3456789102361456L); cardDetails.setCvv(123);
		 * cardDetails.setExpiryMonth(12); cardDetails.setExpiryYear(2050);
		 * cardDetails.setOtp(1234);
		 * 
		 * ProductBean productBean = new ProductBean(); productBean.setId("pId0001");
		 * productBean.setName("It is Product Name"); productBean.setPrice(1234.50);
		 * productBean.setQuantity(100); productBean.setUserBean(userBean);
		 * 
		 * OrderBean orderBean = new OrderBean(); orderBean.setOrderNumber(1111);
		 * orderBean.setProductBean(productBean); orderBean.setQuantity(1);
		 * orderBean.setUserBean(userBean);
		 * 
		 * try { sessionFactory.getCurrentSession().save(userBean);
		 * sessionFactory.getCurrentSession().save(cardDetails);
		 * sessionFactory.getCurrentSession().save(productBean);
		 * sessionFactory.getCurrentSession().save(orderBean);
		 * 
		 * } catch (HibernateException e) { e.printStackTrace();
		 * System.out.println("\n\n\nINSIDE CATCH BLOCK IN init() METHOD...\n" +
		 * "getCurrentSession() Failed...\n\n\n"); Session session =
		 * sessionFactory.openSession(); Transaction tx = session.beginTransaction();
		 * session.save(userBean); System.out.println("UserBean Saved...");
		 * sessionFactory.openSession().save(cardDetails); session.save(productBean);
		 * System.out.println("ProductBean Saved..."); session.save(orderBean);
		 * System.out.println("OrderBean Saved..."); tx.commit();
		 * 
		 * }// end of try-catch
		 */
	}// end of init()

	/*
	 * Implemented - Not Tested
	 * 
	 * @see com.teamsankya.shoppingcart.dao.CartDAO#login(java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public UserBean login(String userId, String password) {

		UserBean userBean = null;
		System.out.println("login using openSession()");
		Session session = sessionFactory.openSession();
		userBean = session.get(UserBean.class, userId);
		session.close();
		if (userBean != null && userBean.getPassword().equals(password)) {
			return userBean;
		}
		return null;

	}// end of login()

	/*
	 * Implemented - Not Tested
	 * 
	 * @see
	 * com.teamsankya.shoppingcart.dao.CartDAO#register(com.teamsankya.shoppingcart.
	 * dto.UserBean)
	 */
	@Override
	public boolean register(UserBean userBean) {
		Session session = null;
		Transaction transaction = null;

		System.out.println("Register using openSession()");
		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		session.save(userBean);
		transaction.commit();
		session.close();
		return true;

	}// end of register()

	/*
	 * Implemented - Not Tested
	 * 
	 * @see com.teamsankya.shoppingcart.dao.CartDAO#getProducts()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<ProductBean> getProducts() {

		List<ProductBean> productBeansList = null;
		Session session = sessionFactory.openSession();
		productBeansList = session.createQuery(" from ProductBean ").getResultList();
		if (productBeansList != null && productBeansList.isEmpty())

		{
			productBeansList = null;
		}
		session.close();
		return productBeansList;

	}// end of getProducts()

	/*
	 * Implemented - Not Tested
	 * 
	 * @see com.teamsankya.shoppingcart.dao.CartDAO#getProducts(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<ProductBean> getProducts(String name) {

		List<ProductBean> productBeansList = null;
		Query<ProductBean> query = null;
		Session session = sessionFactory.openSession();
		query = session.createQuery(" from ProductBean where name =:name ");
		query.setParameter("name", name);
		productBeansList = query.getResultList();
		session.close();
		if (productBeansList != null && productBeansList.isEmpty()) {
			return null;
		}

		return productBeansList;

	}// end of getProducts(name)

	@Override
	public ProductBean getProduct(String id) {
		Session session = sessionFactory.openSession();
		ProductBean bean = session.get(ProductBean.class, id);
		session.close();
		return bean;
	}// end of getProduct(id)

	@Override
	public boolean payNow(CardDetails cardDetails, String pid, UserBean userBean) {
		OrderBean orderBean = new OrderBean();

		orderBean.setProductBean(getProduct(pid));
		orderBean.setQuantity(1);
		orderBean.setUserBean(userBean);

		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();

		session.save(orderBean);
		transaction.commit();
		session.close();
		return true;
	}// end of payNow()

	/*
	 * Implemented - Not Tested
	 * 
	 * @see com.teamsankya.shoppingcart.dao.CartDAO#addProduct(com.teamsankya.
	 * shoppingcart.dto.ProductBean)
	 */
	@Override
	public boolean addProduct(ProductBean productBean) {

		Session session = null;
		Transaction transaction = null;

		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		session.save(productBean);
		transaction.commit();
		session.close();
		return true;
	}// end of addProduct()

}// End of CartDAOImpl
