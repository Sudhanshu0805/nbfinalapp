package com.teamsankya.shoppingcart.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.teamsankya.shoppingcart.dto.ProductBean;
import com.teamsankya.shoppingcart.dto.UserBean;
import com.teamsankya.shoppingcart.service.CartService;

@Controller
@SessionAttributes(names = {"userBean"})
public class ProductController {

	@Autowired
	CartService cartService;

	@RequestMapping(path = "/*", method = {RequestMethod.GET, RequestMethod.POST})
	public String home(ModelMap map) {
		List<ProductBean> productBeansList = cartService.getProducts();

		map.addAttribute("productBeansList", productBeansList);
		System.out.println("going to home page");
		return "home";
	}// end of home()

	@RequestMapping(path = "search", method = RequestMethod.GET)
	public String search(String name, ModelMap map) {
		List<ProductBean> productBeansList = cartService.getProducts(name);

		map.addAttribute("productBeansList", productBeansList);
		map.addAttribute("searchedProduct", name);
		return "home";

	}// end of search()

	@RequestMapping(path = "productPage", method = RequestMethod.GET)
	public String productInfo(String id, ModelMap map) {
		System.out.println("Product Id = " + id);
		map.addAttribute("productBean", cartService.getProduct(id));
		System.out.println("got the product");
		return "productPage";

	}// end of productInfo()

	@RequestMapping(path = "addProduct", method = RequestMethod.GET)
	public String addProduct(ModelMap map) {
		UserBean userBean = (UserBean) map.get("userBean");
		
		if (userBean != null
				&& userBean.getType().equalsIgnoreCase("S")) {
			
			return "addProductForm";
		}
		
		map.addAttribute("msg", "Insufficient Privileges!!!");
		return "index";
		
	}// end of addProduct() - for Add Product Form
	
	@RequestMapping(path = "addProduct", method = RequestMethod.POST)
	public String addProduct(ProductBean productBean, ModelMap map) {
		
		UserBean userBean = (UserBean) map.get("userBean");
		
		if (cartService.addProduct(productBean, userBean)) {
			map.addAttribute("msg", "Product Added Successfully.");
		} else {
			map.addAttribute("msg", "Product Not Added! Please Try Again");
		}
		return "index";

	}// end of addProduct() - after submitting product details

}// End of ProductController
