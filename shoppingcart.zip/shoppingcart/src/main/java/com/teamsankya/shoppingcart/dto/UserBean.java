package com.teamsankya.shoppingcart.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name="user_info")
public class UserBean implements Serializable{
	
	@Id
	@Column(name="user_id",length=20)
	private String userId;

	@Column(name="email",length=30,unique=true,nullable=false)
	private String email;
	
	@Column(name="type",length=1,nullable=false)
	private String type;
	
	@Column(name="password",length=20,nullable=false)
	private String password;
	
	@Column(name="address",length=100,nullable=false)
	private String address;
	
	@Column(name="city",length=30,nullable=false)
	private String city;
	
	@Column(name="state",length=30,nullable=false)
	private String state;
	
	@Column(name="pincode",length=6,nullable=false)
	private int pincode;
	
	@Column(name="phone_number",length=10,nullable=false)
	private long phoneNumber;
	
	// Getters and Setters
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
}
