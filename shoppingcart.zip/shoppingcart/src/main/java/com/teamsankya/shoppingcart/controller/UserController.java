package com.teamsankya.shoppingcart.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.teamsankya.shoppingcart.dto.UserBean;
import com.teamsankya.shoppingcart.service.CartService;

@Controller
@SessionAttributes(names = { "userBean" })
public class UserController {
	
	@Autowired
	private CartService cartService;
	
	@RequestMapping(path = "login", method = RequestMethod.GET)
	public String login() {
		
		return "loginForm";
	}// end of login() - for login form
	
	@RequestMapping(path = "login", method = RequestMethod.POST)
	public String login(String userId, String password, ModelMap map) {
		UserBean userBean = cartService.login(userId, password);

		// Verifying authentication is successful or not
		if (userBean == null) {
			// Authentication Failed
			map.addAttribute("message", "invalid credensials");
			return "loginForm";
		}

		// Forwarding to User Home Page after successful login.
		map.addAttribute("userBean", userBean);
		return "forward:/home";

	}// end of login() - after submitting login form

	@RequestMapping(path = "register", method = RequestMethod.GET)
	public String register() {
		
		return "registerForm";
	}// end of register() - for Registration Form
	
	@RequestMapping(path = "register", method = RequestMethod.POST)
	public String register(UserBean userBean, String retypePassword, ModelMap map) {
		if(cartService.register(userBean, retypePassword)) {
		
		map.addAttribute("msg", "Registered Successfully...");
		return "forward:/home";
		}
		
		map.addAttribute("msg", "Registration Failed!!! Please Fill Correct Details.");
		return "registerForm";

	}// end of register() - for registering user/seller

	@RequestMapping(path = "logout", method = RequestMethod.GET)
	public String logout(ModelMap map, HttpSession session) {
		session.removeAttribute("userBean");
		map.remove("userBean");
		session.invalidate();
		map.addAttribute("msg", "Thank You for shopping with us...");
		
		return "forward:/home";

	}// end of logout()

}// End of UserController
