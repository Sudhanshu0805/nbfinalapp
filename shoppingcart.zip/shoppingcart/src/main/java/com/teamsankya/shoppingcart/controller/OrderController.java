package com.teamsankya.shoppingcart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.teamsankya.shoppingcart.dto.CardDetails;
import com.teamsankya.shoppingcart.dto.TransactionDetails;
import com.teamsankya.shoppingcart.dto.UserBean;
import com.teamsankya.shoppingcart.service.CartService;

@Controller()
@SessionAttributes(names = {"userBean"})
public class OrderController {
	
	@Autowired
	CartService cartService;
	
	@RequestMapping(path = "buy", method = RequestMethod.GET)
	public String buy(String pid, ModelMap map) {
		map.addAttribute("pid", pid);
		
		return "cardDetails";

	}// end of buy()

	@RequestMapping(path = "payNow", method = RequestMethod.POST)
	public String payNow(@SessionAttribute(name="userBean", required=false)UserBean userBean, CardDetails cardDetails, String pid, ModelMap map) {
		if(userBean==null) {
			return "loginForm";
		}
		
		TransactionDetails transactionDetails = cartService.payNow(cardDetails, pid, userBean);
		map.addAttribute("transactionDetails", transactionDetails);
		return "orderDetails";
		
		//return "forward:/orderDetails";

		//return "redirect:/orderDetails";
		
	}// end of payNow()
	
	@RequestMapping(path = "orderDetails", method = {RequestMethod.GET, RequestMethod.POST})
	public String orderDetails(TransactionDetails transactionDetails, ModelMap map) {
		
		//map.addAttribute("transactionDetails", transactionDetails);
		return "orderDetails";
		
	}// end of orderDetails()

}// End of OrderController
