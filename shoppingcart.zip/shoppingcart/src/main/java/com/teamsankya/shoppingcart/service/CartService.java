package com.teamsankya.shoppingcart.service;

import java.util.List;

import com.teamsankya.shoppingcart.dto.CardDetails;
import com.teamsankya.shoppingcart.dto.ProductBean;
import com.teamsankya.shoppingcart.dto.TransactionDetails;
import com.teamsankya.shoppingcart.dto.UserBean;

public interface CartService {
	UserBean login(String userId, String password);
	boolean register(UserBean bean, String retypePassword);
	List<ProductBean> getProducts();
	List<ProductBean> getProducts(String name);
	ProductBean getProduct(String id);
	boolean addProduct(ProductBean productBean, UserBean userBean);
	TransactionDetails payNow(CardDetails cardDetails, String pid, UserBean userBean);
	
}//End of interface