package com.teamsankya.shoppingcart.dto;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name="odrer_info")
public class OrderBean implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="odrer_number")
	private int orderNumber;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="id",nullable=false)
	private ProductBean productBean;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="user_id",nullable=false)
	private UserBean userBean;
	
	@Column(name="quantity",nullable=false)
	private int quantity;
	
	// Getters and Setters
	public int getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}
	public ProductBean getProductBean() {
		return productBean;
	}
	public void setProductBean(ProductBean productBean) {
		this.productBean = productBean;
	}
	public UserBean getUserBean() {
		return userBean;
	}
	public void setUserBean(UserBean userBean) {
		this.userBean = userBean;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
}
